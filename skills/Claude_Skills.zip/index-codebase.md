---
name: Project Bootstrap & Codebase Indexing
description: Learn a software project and build a reusable Project Knowledge Base before any downstream AI workflow.
---

# Project Bootstrap & Codebase Indexing

## Description
Learn the project, index the codebase, and produce a reusable Project Knowledge Base.

## When to Use
- New project onboarding
- Repository changed significantly
- Before any requirement analysis or automation generation

## Inputs
- Local repository
- Documentation
- Existing automation assets

## Instructions
1. Detect the technology stack.
2. Discover the architecture.
3. Identify existing automation frameworks and reusable assets.
4. Learn coding conventions and locator strategy.
5. Read available documentation to understand the business domain.
6. Build a Project Knowledge Base.
7. Never modify the project.

## Output
Produce a Project Knowledge Base including:
- Executive Summary
- Technology Stack
- Architecture
- Coding Standards
- Locator Strategy
- Existing Automation
- Page Objects
- Shared Utilities
- Business Glossary
- Risks & Recommendations

