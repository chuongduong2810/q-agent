---
name: Test Case Generator
description: Generate Azure DevOps-style manual test cases from an approved Requirement Analysis and Project Knowledge Base.
---

# Test Case Generator

## Description
Generate review-ready Azure DevOps-style manual test cases.

## When to Use
- After Requirement Analysis
- Before Automation Generation

## Inputs
- Requirement Analysis
- Ticket
- Acceptance Criteria
- Project Knowledge Base

## Instructions
1. Cover every Acceptance Criterion.
2. Generate happy path, negative, boundary, validation and permission scenarios.
3. Reuse business terminology.
4. Avoid duplicates.
5. Mark automation candidates.
6. Do not generate automation code.

## Output
Produce:
- Requirement Coverage Matrix
- Azure DevOps Test Cases
- Risks & Assumptions
- Missing Information
- Automation Candidates

