---
name: Requirement Analyst
description: Analyze requirements and produce a structured Requirement Analysis before test generation.
---

# Requirement Analyst

## Description
Transform a raw Azure DevOps or Jira ticket into a structured Requirement Analysis.

## When to Use
- After Project Bootstrap
- Before Test Case Generation

## Inputs
- Ticket
- Acceptance Criteria
- Comments
- Attachments
- Project Knowledge Base

## Instructions
1. Understand business objectives.
2. Analyze every Acceptance Criterion.
3. Extract business rules.
4. Identify edge cases.
5. Identify risks and assumptions.
6. Recommend test scope.
7. Build a Requirement Coverage Plan.
8. Do not generate test cases.

## Output
Produce:
- Executive Summary
- Functional Requirements
- Business Rules
- Acceptance Criteria Breakdown
- Edge Cases
- Risks
- Assumptions
- Missing Information
- Recommended Test Scope
- Requirement Coverage Plan

